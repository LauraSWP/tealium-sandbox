Icon Requirements:
- icon-16.png: 16x16 pixels
- icon-48.png: 48x48 pixels  
- icon-128.png: 128x128 pixels

Design: Tealium blue (#0073CF) background with white "T" or puzzle piece icon

Temporary: Use simple colored squares for now, replace with proper icons later.

